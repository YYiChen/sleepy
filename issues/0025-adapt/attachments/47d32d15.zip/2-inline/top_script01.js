window.CryptoJS = CryptoJS;
      /* 判断是否是IE浏览器，包括Edge浏览器 */
      function IEVersion () {
          // 取得浏览器的userAgent字符串
          var userAgent = navigator.userAgent
          var browserDOM = document.getElementById('browser-filter-bg')
          // 判断是否IE浏览器
          var isIE = userAgent.indexOf('compatible') > -1 && userAgent.indexOf('MSIE') > -1
          if (isIE) {
              var reIE = new RegExp('MSIE (\\d+\\.\\d+);')
              reIE.test(userAgent)
              var fIEVersion = parseFloat(RegExp['$1'])
              // 判断是否为10以版本
              if (fIEVersion < 11) {
                  browserDOM.style.display = 'block'
                  document.getElementById('browserDialog-confirm').onclick = function () {
                    browserDOM.style.display = 'none'
                  }
              }
          }
      }
      IEVersion()